<!DOCTYPE html>
<html>
<head>
    <title>Property Maintenance</title>
</head>
<body style="background-color: #88BDBC">


<?php


$con = mysqli_connect("db.luddy.indiana.edu", "i308s24_team66", "my+sql=i308s24_team66", "i308s24_team66");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$propertyId = $_GET['propertyId'];



$sql = "SELECT m.propertyId, m.type as maintenance_type, p.type,CONCAT('$', ' ', m.cost) as maintenance_cost
    FROM maintenanceChores as m
    JOIN property as p on p.propertyId = m.propertyId
    WHERE m.propertyId = $propertyId
    GROUP BY m.maintenanceId
    ORDER BY maintenance_cost DESC;";

$result = mysqli_query($con, $sql);
$num_rows = mysqli_num_rows($result);

if ($num_rows > 0) {
    echo "<h2 style='text-align: center'>Maintenance Chores Cost for Selected Property</h2>";
    echo "<center><table style='border-collapse: collapse;' width='750'>";
    echo "<tr height=50>
            <th style='border: 2px solid black;' >Maintenance Type</th>
            <th style='border: 2px solid black;' >Maintenance Cost</th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) {
            echo "<tr height=50>
                        <td style='border: 2px solid black;' >" . $row["maintenance_type"]."</td>
                        <td style='border: 2px solid black;' >" . $row["maintenance_cost"]."</td>
                    </tr>";
    }
    echo "<table></center><hr color='black' size='2'>";
} else { echo "0 results"; }

echo "<center><button onclick='window.history.go(-1)'  style='width: 125px; height: 50px; font-size: 16px;'><b>Return</b></button></center>";


mysqli_free_result($result);
mysqli_close($con);
?>


</body>
</html>