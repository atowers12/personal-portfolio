<!DOCTYPE html>
<html>
<head>
    <title>Above Average Rent</title>
</head>
<body style="background-color: #88BDBC">

<?php
$con = mysqli_connect("db.luddy.indiana.edu", "i308s24_team66", "my+sql=i308s24_team66", "i308s24_team66");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


$property_type = $_POST['property-type'];


$sql = "SELECT p.propertyId, p.addressStreet, CONCAT(p.addressCity, ', Indiana ', p.addressZip) as city_state_zip, 
                CONCAT('$', ' ', L.monthlyRent) as monthlyRent
        FROM property as p
        JOIN lease as L on L.propertyId=p.propertyId
        WHERE L.monthlyRent > (SELECT AVG(monthlyRent) FROM lease)
        AND p.type = '$property_type'
        GROUP BY propertyId";
$result = mysqli_query($con, $sql);
$num_rows = mysqli_num_rows($result);

if ($num_rows > 0) {
    echo "<h2 style='text-align: center'>Properties with Above Average Rent</h2>";
    echo "<center><table style='border-collapse: collapse;' width='900'>
            <tr height=75>
                <th style='border: 2px solid black;'>Property ID</th>
                <th style='border: 2px solid black;'>Address</th>
                <th style='border: 2px solid black;'>City, State, Zip</th>
                <th style='border: 2px solid black;'>Monthly Rent</th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr height=75>
                <td style='border: 2px solid black;'>" . $row["propertyId"] . "</td>
                <td style='border: 2px solid black;'>" . $row["addressStreet"] . "</td>
                <td style='border: 2px solid black;'>" . $row["city_state_zip"] . "</td>
                <td style='border: 2px solid black;'>" . $row["monthlyRent"] . "</td>
            </tr>";
    }
    echo "</table></center><hr color='black' size='2'>";
} else { 
    echo "0 results"; 
}

echo "<center><button onclick='goBack()'  style='width: 125px; height: 50px; font-size: 16px;'><b>Home</b></button></center>";
echo "<script>
function goBack() {
  window.location.href = 'index.php';
}
</script>";


mysqli_free_result($result);
mysqli_close($con);
?>


</body>
</html>