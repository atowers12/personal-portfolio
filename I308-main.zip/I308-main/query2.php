<!DOCTYPE html>
<html>
<head>
    <title>Legal Info</title>
</head>
<body style="background-color: #88BDBC">


<?php
$con = mysqli_connect("db.luddy.indiana.edu", "i308s24_team66", "my+sql=i308s24_team66", "i308s24_team66");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$legal_tenant = $_POST['legal-tenant'];

$sql = "SELECT t.tenantId, l.caseId, CONCAT(t.nameFirst,' ', t.nameMiddle,' ', t.nameLast) as full_name, l.description, l.outcome
        FROM tenant as t 
        JOIN legalAction as l on l.tenantId=t.tenantId
        WHERE t.backgroundCheckStatus = 'Conditional' 
        AND t.tenantId IN (SELECT tenantId from legalAction)
        AND t.tenantId = $legal_tenant";
$result = mysqli_query($con, $sql);
$num_rows = mysqli_num_rows($result);

if ($num_rows > 0) {
    echo "<h2 style='text-align: center'>Legal Actions Against Tenants with Conditional Background Check</h2>";
    echo "<center><table style='border-collapse: collapse;' width='900'>
            <tr height=75>
                <th style='border: 2px solid black;'>Tenant ID</th>
                <th style='border: 2px solid black;' >Case ID</th>
                <th style='border: 2px solid black;' >Tenant Name</th>
                <th style='border: 2px solid black;' >Description</th>
                <th style='border: 2px solid black;' >Outcome</th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr height=75>
                <td style='border: 2px solid black;'>" . $row["tenantId"] . "</td>
                <td style='border: 2px solid black;' >" . $row["caseId"] . "</td>
                <td style='border: 2px solid black;' >" . $row["full_name"] . "</td>
                <td style='border: 2px solid black;' >" . $row["description"] . "</td>
                <td style='border: 2px solid black;' >" . $row["outcome"] . "</td>
            </tr>";
    }
    echo "</table></center><hr color='black' size='2'>";
} else { 
    echo "0 results"; 
}

echo "<center><button onclick='goBack()'  style='width: 125px; height: 50px; font-size: 16px;'><b>Home</b></button></center>";
echo "<script>
function goBack() {
  window.location.href = 'index.php';
}
</script>";

mysqli_free_result($result);
mysqli_close($con);
?>

</body>
</html>