/*Participation: Jack, Iman, Maddie, Andrew*/
/*Project SQL Statements*/

/*     Query #1: Total Maintenance Cost by Property Type   */

SELECT m.propertyId, p.type,CONCAT('$', ' ', SUM(m.cost)) as total_maintenance_cost
FROM maintenanceChores as m
JOIN property as p on p.propertyId = m.propertyId
GROUP BY p.propertyId
ORDER BY total_maintenance_cost DESC;

/*     Query #2: Legal Actions Against Tenants with Background Check Conditional    */

SELECT t.tenantId, l.caseId, CONCAT(t.nameFirst,' ', t.nameMiddle,' ', t.nameLast)as full_name, l.description, l.outcome
FROM tenant as t 
JOIN legalAction as l on l.tenantId=t.tenantId
WHERE t.backgroundCheckStatus = 'Conditional' 
AND t.tenantId IN (SELECT tenantId from legalAction);

/*     Query #3: Lease Duration and Cost for a Given Property   */

SELECT L.propertyId, L.leaseId, L.startDate, L.endDate, TIMESTAMPDIFF(MONTH, L.startDate, L.endDate) as lease_duration, CONCAT('$', ' ', TIMESTAMPDIFF(MONTH, L.startDate, L.endDate) * L.monthlyRent)  as totalRentByLease, o.ownerId, CONCAT(o.nameFirst, ' ', o.nameLast) as owner_receiving_payment
FROM lease as L
JOIN property as p on p.propertyId = L.propertyId
JOIN owner as o on o.ownerId = p.ownerId
GROUP BY L.leaseId;

/*     Query #4: Owner Name and Revenue across all Properties  */

SELECT o.ownerId, CONCAT(o.nameFirst, ' ', o.nameLast) as ownerName, CONCAT( '$', ' ' , ROUND((SUM(TIMESTAMPDIFF(MONTH, L.startDate, L.endDate) * L.monthlyRent)) * (o.managementFeePercent/100),2)) as ownerRevenue
FROM owner as o 
JOIN property as p on p.ownerId=o.ownerId
JOIN lease as L on L.propertyId =p.propertyId
GROUP BY L.propertyId;
 
/*     Query #5:  Properties with Above Average Rent   */

SELECT p.propertyId, p.addressStreet, CONCAT(p.addressCity, ', Indiana ', p.addressZip) as city_state_zip, CONCAT('$', ' ', L.monthlyRent) as monthlyRent
FROM property as p
JOIN lease as L on L.propertyId=p.propertyId
WHERE L.monthlyRent > (SELECT AVG(monthlyRent) FROM lease)
GROUP BY propertyId;
