<!DOCTYPE html>
<html>
<head>
    <title>Owner Revenue</title>
</head>
<body style="background-color: #88BDBC">

<?php
$con = mysqli_connect("db.luddy.indiana.edu", "i308s24_team66", "my+sql=i308s24_team66", "i308s24_team66");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


$owner = $_POST['owner'];


$sql = "SELECT o.ownerId, CONCAT(o.nameFirst, ' ', o.nameLast) as ownerName, 
                CONCAT('$', ' ', ROUND((SUM(TIMESTAMPDIFF(MONTH, L.startDate, L.endDate) * L.monthlyRent)) * (o.managementFeePercent/100), 2)) as ownerRevenue
        FROM owner as o 
        JOIN property as p on p.ownerId=o.ownerId
        JOIN lease as L on L.propertyId =p.propertyId
        WHERE o.ownerId = $owner
        GROUP BY L.propertyId";
$result = mysqli_query($con, $sql);
$num_rows = mysqli_num_rows($result);

if ($num_rows > 0) {
    echo "<h2 style='text-align: center'>Owner Revenue</h2>";
    echo "<center><table style='border-collapse: collapse;' width='900'>
            <tr height=75>
                <th style='border: 2px solid black;'>Owner ID</th>
                <th style='border: 2px solid black;'>Owner Name</th>
                <th style='border: 2px solid black;'>Owner Revenue</th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr height=75>
                <td style='border: 2px solid black;'>" . $row["ownerId"] . "</td>
                <td style='border: 2px solid black;'>" . $row["ownerName"] . "</td>
                <td style='border: 2px solid black;'>" . $row["ownerRevenue"] . "</td>
            </tr>";
    }
    echo "</table></center><hr color='black' size='2'>";
} else { 
    echo "0 results"; 
}

echo "<center><button onclick='goBack()'  style='width: 125px; height: 50px; font-size: 16px;'><b>Home</b></button></center>";
echo "<script>
function goBack() {
  window.location.href = 'index.php';
}
</script>";

mysqli_free_result($result);
mysqli_close($con);
?>

</body>
</html>