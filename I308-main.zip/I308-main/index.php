<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/skeleton/2.0.4/skeleton.min.css">
    <link rel="stylesheet" href="theme.css">
    <title>Polly and Peter's Properties</title>
</head>
<body style="background-color: #88BDBC">
    <h1 style="text-align:center; padding:20px;"><b>Polly and Peter's Properties</b></h1> 
    <h5 style="text-align:center; padding:20px;"><b>Polly and Peter's Properties is a property management company owned by Polly and Peter Purkiss that specializes in student rentals that include apartments and single family homes </b></h5> 
    <hr style="border-top: 5px solid black"> 
    <div class="container">
        <div class = "row">
            <div class="six columns" style="border: 4px solid black; padding: 15px; border-radius: 20px">
                <h3 style="text-align: center;">Property Maintenance</h3>
                <h5 style="text-align: center">Total Maintenance Chores Cost by Property Type</h5>
                
                
                
                <center><form action = "query1.php" method ="post">
                    <select name = "property-type">
                    <?php
                    $con = mysqli_connect("db.luddy.indiana.edu","i308s24_team66","my+sql=i308s24_team66", "i308s24_team66");
                    if (!$con) { die("Connection failed: " . mysqli_connect_error());}
                    $sql = "SELECT DISTINCT type from property";
                    $result = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value=" . $row['type'] . ">" . $row['type'] . "</option>";
                    }
                    ?>
                    </select>
                    <br>
                    <input type="submit" style="color: black; border: 2px solid black; text-align: center">
                    </form></center>


            </div>
            <div class="six columns" style="border: 4px solid black; padding: 15px; border-radius: 20px">
                <h3 style="text-align: center;">Legal Action</h3>
                <h5 style="text-align: center;">Legal Actions Against Tenants with Background Check Conditional</h5>
                <center><form action = "query2.php" method ="post">
                    <select name = "legal-tenant">
                    <?php
                    $con = mysqli_connect("db.luddy.indiana.edu","i308s24_team66","my+sql=i308s24_team66", "i308s24_team66");
                    if (!$con) { die("Connection failed: " . mysqli_connect_error());}
                    $sql = "SELECT DISTINCT t.tenantId, CONCAT(t.nameFirst,' ', t.nameMiddle,' ', t.nameLast) as full_name
                        FROM tenant as t 
                        JOIN legalAction as l on l.tenantId=t.tenantId
                        WHERE t.backgroundCheckStatus = 'Conditional' 
                        AND t.tenantId IN (SELECT tenantId from legalAction)";
                    $result = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value=" . $row['tenantId'] . ">" . $row['full_name'] . "</option>";
                    }
                    ?>
                    </select>
                    <br>
                    <input type="submit" style="color: black; border: 2px solid black; text-align: center">
                    </form>
                </center>
            </div>
        </div>
        <br>
        <div class = "row">
            <div class="six columns" style="border: 4px solid black; padding: 15px; border-radius: 20px">
                <h3 style="text-align: center;">Lease</h3>
                <h5 style="text-align: center;">Lease Duration and Cost for a Given Property</h5>
                
            
                <center><form action = "query3.php" method ="post">
                    <select name = "property">
                    <?php
                    $con = mysqli_connect("db.luddy.indiana.edu","i308s24_team66","my+sql=i308s24_team66", "i308s24_team66");
                    if (!$con) { die("Connection failed: " . mysqli_connect_error());}
                    $sql = "SELECT propertyId, CONCAT(addressStreet,' ', addressCity, ', Indiana ', addressZip) as full_address from property;";
                    $result = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value=" . $row['propertyId'] . ">" . $row['full_address'] . "</option>";
                    }
                    ?>
                    </select>
                    <br>
                    <input type="submit" style="color: black; border: 2px solid black; text-align: center">
                    </form></center>

            </div>
            <div class="six columns" style="border: 4px solid black; padding: 15px; border-radius: 20px">
                <h3 style="text-align: center;">Owner Properties</h3>
                <h5 style="text-align: center;">Owner Name and Revenue across all Properties</h5>
           
                
                
                <center><form action = "query4.php" method ="post">
                    <select name = "owner">
                    <?php
                    $con = mysqli_connect("db.luddy.indiana.edu","i308s24_team66","my+sql=i308s24_team66", "i308s24_team66");
                    if (!$con) { die("Connection failed: " . mysqli_connect_error());}
                    $sql = "SELECT ownerId, CONCAT(nameFirst, ' ', nameLast) as ownerName from owner;";
                    $result = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value=" . $row['ownerId'] . ">" . $row['ownerName'] . "</option>";
                    }
                    ?>
                    </select>
                    <br>
                    <input type="submit" style="color: black; border: 2px solid black; text-align: center">
                    </form></center>


            </div>
        </div>
        <br>
        <div class = "row">
            <div class="twelve columns" style="border: 4px solid black; padding: 15px; border-radius: 20px">
                <h3 style="text-align: center;">Pricey Properties</h3>
                <h5 style="text-align: center;">Properties with Above Average Rent (Above $1047.31)</h5>
                <center><form action = "query5.php" method ="post">
                    <select name = "property-type">
                    <?php
                    $con = mysqli_connect("db.luddy.indiana.edu","i308s24_team66","my+sql=i308s24_team66", "i308s24_team66");
                    if (!$con) { die("Connection failed: " . mysqli_connect_error());}
                    $sql = "SELECT DISTINCT type from property";
                    $result = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value=" . $row['type'] . ">" . $row['type'] . "</option>";
                    }
                    ?>
                    </select>
                    <br>
                    <input type="submit" style="color: black; border: 2px solid black; text-align: center">
                    </form></center>

            </div>
        </div>
    </div>
    <hr style="border-top: 5px solid black"> 
</body>
</html>