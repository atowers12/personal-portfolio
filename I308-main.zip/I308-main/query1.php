<!DOCTYPE html>
<html>
<head>
    <title>Maintenance</title>
</head>
<body style="background-color: #88BDBC">

<?php

$con = mysqli_connect("db.luddy.indiana.edu", "i308s24_team66", "my+sql=i308s24_team66", "i308s24_team66");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$property_type = $_POST['property-type'];

$sql = "SELECT m.propertyId, p.type,CONCAT('$', ' ', SUM(m.cost)) as total_maintenance_cost, CONCAT(p.addressStreet,' ', p.addressCity, ', Indiana ', p.addressZip) as full_address
    FROM maintenanceChores as m
    JOIN property as p on p.propertyId = m.propertyId
    WHERE p.type = '$property_type'
    GROUP BY p.propertyId
    ORDER BY total_maintenance_cost DESC";
$result = mysqli_query($con, $sql);
$num_rows = mysqli_num_rows($result);

if ($num_rows > 0) {
    echo "<h2 style='text-align: center'>Total Maintenance Chores Cost for $property_type</h2>";
    echo "<h3 style='text-align: center'> Click on Address Link to view each individual charge</h3>";
    echo "<center><table style='border-collapse: collapse;' width='750'>";
    echo "<tr  height=75>
            <th style='border: 2px solid black;' >Property Address</th>
            <th style='border: 2px solid black;' >Property Type</th>
            <th style='border: 2px solid black;'>Total Maintenance Cost</th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) {
            echo "<tr height=75px>
                            <td style='border: 2px solid black;'> 
                                <a href='subquery.php?propertyId=" . $row["propertyId"] . "'>" . $row["full_address"] . "</a>
                            </td>
                            <td style='border: 2px solid black;'>" . $row["type"]."</td>
                            <td style='border: 2px solid black;'>" . $row["total_maintenance_cost"]."</td>
                    </tr>";
    }
    echo "<table></center><hr color='black' size='2'>";
} else { echo "0 results"; }

echo "<center><button onclick='goBack()'  style='width: 125px; height: 50px; font-size: 16px;'><b>Home</b></button></center>";
echo "<script>
function goBack() {
  window.location.href = 'index.php';
}
</script>";

mysqli_free_result($result);
mysqli_close($con);
?>


</body>
</html>