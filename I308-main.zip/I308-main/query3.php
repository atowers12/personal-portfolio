<!DOCTYPE html>
<html>
<head>
    <title>Lease Info</title>
</head>
<body style="background-color: #88BDBC">


<?php
$con = mysqli_connect("db.luddy.indiana.edu", "i308s24_team66", "my+sql=i308s24_team66", "i308s24_team66");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$property = $_POST['property'];


$sql = "SELECT L.propertyId, L.leaseId, L.startDate, L.endDate, TIMESTAMPDIFF(MONTH, L.startDate, L.endDate) as lease_duration, 
                CONCAT('$', ' ', TIMESTAMPDIFF(MONTH, L.startDate, L.endDate) * L.monthlyRent) as totalRentByLease, 
                o.ownerId, CONCAT(o.nameFirst, ' ', o.nameLast) as owner_receiving_payment
        FROM lease as L
        JOIN property as p on p.propertyId = L.propertyId
        JOIN owner as o on o.ownerId = p.ownerId
        WHERE p.propertyId = $property
        GROUP BY L.leaseId";
$result = mysqli_query($con, $sql);
$num_rows = mysqli_num_rows($result);

if ($num_rows > 0) {
    echo "<h2 style='text-align: center'>Lease Information</h2>";
    echo "<center><table style='border-collapse: collapse;' width='1000'>
            <tr height=75>
                <th style='border: 2px solid black;'>Property ID</th>
                <th style='border: 2px solid black;'>Lease ID</th>
                <th style='border: 2px solid black;'>Start Date</th>
                <th style='border: 2px solid black;'>End Date</th>
                <th style='border: 2px solid black;'>Lease Duration (Months)</th>
                <th style='border: 2px solid black;'>Total Rent by Lease</th>
                <th style='border: 2px solid black;'>Owner ID</th>
                <th style='border: 2px solid black;'>Owner Receiving Payment</th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr height=75>
                <td style='border: 2px solid black;'>" . $row["propertyId"] . "</td>
                <td style='border: 2px solid black;'>" . $row["leaseId"] . "</td>
                <td style='border: 2px solid black;'>" . $row["startDate"] . "</td>
                <td style='border: 2px solid black;'>" . $row["endDate"] . "</td>
                <td style='border: 2px solid black;'>" . $row["lease_duration"] . "</td>
                <td style='border: 2px solid black;'>" . $row["totalRentByLease"] . "</td>
                <td style='border: 2px solid black;'>" . $row["ownerId"] . "</td>
                <td style='border: 2px solid black;'>" . $row["owner_receiving_payment"] . "</td>
            </tr>";
    }
    echo "</table></center><hr color='black' size='2'>";
} else { 
    echo "0 results"; 
}

echo "<center><button onclick='goBack()'  style='width: 125px; height: 50px; font-size: 16px;'><b>Home</b></button></center>";
echo "<script>
function goBack() {
  window.location.href = 'index.php';
}
</script>";

mysqli_free_result($result);
mysqli_close($con);
?>


</body>
</html>